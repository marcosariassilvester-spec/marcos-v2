# marc.OS v2
Sube marcOS_v2.zip al repositorio y crea .github/workflows/build.yml. El APK aparece en Releases.
