package com.marc.os

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

val MONO = FontFamily.Monospace
val ACCENTS = listOf(Color(0xFF00F5FF), Color(0xFFFF2BD6), Color(0xFF39FF14), Color(0xFFFFB000))
val ACC_NAMES = listOf("CIAN", "MAGENTA", "VERDE", "ÁMBAR")
val NOTES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
val SCALES = listOf(
    "Mayor" to intArrayOf(0, 2, 4, 5, 7, 9, 11), "Menor" to intArrayOf(0, 2, 3, 5, 7, 8, 10),
    "Pentatónica" to intArrayOf(0, 2, 4, 7, 9), "Pent. menor" to intArrayOf(0, 3, 5, 7, 10),
    "Dórico" to intArrayOf(0, 2, 3, 5, 7, 9, 10), "Frigio" to intArrayOf(0, 1, 3, 5, 7, 8, 10),
    "Lidio" to intArrayOf(0, 2, 4, 6, 7, 9, 11), "Mixolidio" to intArrayOf(0, 2, 4, 5, 7, 9, 10),
    "Blues" to intArrayOf(0, 3, 5, 6, 7, 10), "Cromática" to IntArray(12) { it }
)
val CHORDS = listOf(
    "1-3-5" to intArrayOf(0, 2, 4), "1-3-5-7" to intArrayOf(0, 2, 4, 6), "sus2" to intArrayOf(0, 1, 4),
    "sus4" to intArrayOf(0, 3, 4), "1-3-5-9" to intArrayOf(0, 2, 4, 8)
)
val MODES = listOf("NOTAS", "ACORDES", "BATERÍA", "SECUENCIA")
val FN = listOf("VOL", "CUT", "RES", "ATK", "REL", "DLY", "ONDA", "SWG")
val WAVES = listOf("SIN", "TRI", "SAW", "SQR")

fun laneColor(l: Int): Color = if (l < 16) Color.hsv((l * 22f) % 360f, .7f, .9f) else Color.hsv(200f + (l - 16) * 9f, .6f, .9f)

class Inst {
    var mode by mutableIntStateOf(0)
    var root by mutableIntStateOf(0)
    var scale by mutableIntStateOf(0)
    var oct by mutableIntStateOf(3)
    var chord by mutableIntStateOf(0)
    var bpm by mutableIntStateOf(110)
    var playing by mutableStateOf(false)
    var len by mutableIntStateOf(16)
    var lane by mutableIntStateOf(0)
    var cur by mutableIntStateOf(-1)
    var lat by mutableFloatStateOf(-1f)
    var patVer by mutableIntStateOf(0)
    var accent by mutableIntStateOf(0)
    var bursts by mutableIntStateOf(2)
    var led by mutableFloatStateOf(1f)
    var velMin by mutableFloatStateOf(.55f)
    var fine by mutableStateOf(false)
    val faders = mutableStateListOf(.8f, .8f, .15f, 0f, .3f, .15f, .5f, 0f)
    val pat = IntArray(32).also { it[0] = 0x1111; it[2] = 0x1010; it[4] = 0x5555; it[16] = 2313 }

    fun deg(d: Int): Int {
        val s = SCALES[scale].second; val n = s.size
        return 12 * (oct + 1) + root + Math.floorDiv(d, n) * 12 + s[Math.floorMod(d, n)]
    }
    fun toggle(l: Int, s: Int) {
        pat[l] = pat[l] xor (1 shl s)
        NativeAudio.setCell(l, s, ((pat[l] shr s) and 1) == 1)
        patVer++
    }
    fun setFader(i: Int, v: Float) { faders[i] = v; NativeAudio.setParam(i, v) }

    fun press(r: Int, c: Int, vel: Float, base: Int): IntArray {
        when (mode) {
            0 -> { NativeAudio.noteOn(base, deg(c + r * 3), vel); return intArrayOf(base) }
            1 -> {
                val o = CHORDS[chord].second
                o.forEachIndexed { k, x -> NativeAudio.noteOn(base + k, deg(c + r * 3 + x), vel * .85f) }
                return IntArray(o.size) { base + it }
            }
            2 -> { if (r < 4 && c < 4) NativeAudio.drum(r * 4 + c, vel) }
            else -> {
                if (r >= 4) { val st = (7 - r) * 8 + c; if (st < len) toggle(lane, st) }
                else {
                    val l = if (c < 4) r * 4 + c else 16 + r * 4 + (c - 4)
                    lane = l
                    if (l < 16) NativeAudio.drum(l, vel) else { NativeAudio.noteOn(base, deg(l - 16), vel); return intArrayOf(base) }
                }
            }
        }
        return IntArray(0)
    }

    fun padColor(r: Int, c: Int, acc: Color): Color? {
        when (mode) {
            0, 1 -> { val n = SCALES[scale].second.size; val i = Math.floorMod(c + r * 3, n); return if (i == 0) acc else Color.hsv(i * 360f / n, .55f, .5f) }
            2 -> return if (r < 4 && c < 4) Color.hsv((r * 4 + c) * 22f, .7f, .85f) else null
            else -> {
                if (r >= 4) {
                    val k = (7 - r) * 8 + c
                    if (k >= len) return null
                    if (k == cur) return Color.White
                    if (((pat[lane] shr k) and 1) == 1) return laneColor(lane)
                    for (l in 0 until 32) if (((pat[l] shr k) and 1) == 1) return Color(0xFF3A4A5C)
                    return null
                }
                return laneColor(if (c < 4) r * 4 + c else 16 + r * 4 + (c - 4))
            }
        }
    }
}

@Composable
fun Neon(text: String, on: Boolean, acc: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(6.dp)
    Box(
        modifier.clip(sh).background(if (on) acc.copy(alpha = .22f) else Color(0xFF0B1118))
            .border(1.dp, if (on) acc else acc.copy(alpha = .4f), sh).clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (on) acc else Color(0xFFB8C7D9), fontFamily = MONO, fontSize = 11.sp, maxLines = 1) }
}

@Composable
fun NeonDrop(label: String, value: String, options: List<String>, acc: Color, onSel: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Neon("$label: $value ▾", false, acc) { open = true }
        DropdownMenu(open, { open = false }, modifier = Modifier.background(Color(0xFF0B1118)).border(1.dp, acc)) {
            options.forEachIndexed { i, o ->
                DropdownMenuItem(text = { Text(o, color = acc, fontFamily = MONO, fontSize = 12.sp) }, onClick = { onSel(i); open = false })
            }
        }
    }
}

@Composable
fun PadGrid(s: Inst, acc: Color, modifier: Modifier) {
    var lit by remember { mutableStateOf(setOf<Int>()) }
    val held = remember { HashMap<Long, IntArray>() }
    val heldPad = remember { HashMap<Long, Int>() }
    Canvas(modifier.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                for (c in ev.changes) {
                    val key = c.id.value
                    if (c.pressed && !c.previousPressed) {
                        val col = (c.position.x / size.width * 8).toInt().coerceIn(0, 7)
                        val fy = c.position.y / size.height * 8
                        val r = 7 - fy.toInt().coerceIn(0, 7)
                        val vel = (s.velMin + (1f - s.velMin) * (1f - (fy - fy.toInt()))).coerceIn(.2f, 1f)
                        held[key] = s.press(r, col, vel, (key % 10).toInt() * 10)
                        heldPad[key] = r * 8 + col
                        lit = lit + (r * 8 + col)
                    } else if (!c.pressed && c.previousPressed) {
                        held.remove(key)?.forEach { NativeAudio.noteOff(it) }
                        heldPad.remove(key)?.let { p -> lit = lit - p }
                    }
                    c.consume()
                }
            }
        }
    }) {
        val ver = s.patVer; val cs = size.width / 8f
        if (ver < 0) return@Canvas
        for (vr in 0..7) for (c in 0..7) {
            val r = 7 - vr
            val base = s.padColor(r, c, acc)
            val on = (r * 8 + c) in lit
            val fill = if (on) (base ?: acc) else base
            val tl = Offset(c * cs + 3f, vr * cs + 3f); val sz = Size(cs - 6f, cs - 6f)
            drawRoundRect(Color(0xFF0B1118), tl, sz, CornerRadius(8f))
            if (fill != null) drawRoundRect(fill.copy(alpha = if (on) 1f else .5f * s.led), tl, sz, CornerRadius(8f))
            val line = fill ?: acc
            drawRoundRect(line.copy(alpha = if (on) 1f else (if (fill != null) .9f else .25f) * s.led.coerceAtLeast(.4f)), tl, sz, CornerRadius(8f), style = Stroke(2f))
            if (s.mode == 3 && r < 4 && (if (c < 4) r * 4 + c else 16 + r * 4 + (c - 4)) == s.lane)
                drawRoundRect(Color.White, tl, sz, CornerRadius(8f), style = Stroke(4f))
        }
    }
}

@Composable
fun Fader(i: Int, s: Inst, acc: Color, modifier: Modifier) {
    val v = s.faders[i]
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0B1118))
                .border(1.dp, acc.copy(alpha = .4f), RoundedCornerShape(6.dp))
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val c = awaitPointerEvent().changes[0]
                            if (c.pressed) {
                                val h = size.height.toFloat()
                                val nv = if (s.fine && c.previousPressed) s.faders[i] - (c.position.y - c.previousPosition.y) / h * .25f
                                else 1f - c.position.y / h
                                s.setFader(i, nv.coerceIn(0f, 1f))
                                c.consume()
                            }
                        }
                    }
                }
        ) { Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(v).background(acc.copy(alpha = .55f))) }
        Text(FN[i], color = acc, fontFamily = MONO, fontSize = 9.sp)
        Text(if (i == 6) WAVES[minOf(3, (v * 4).toInt())] else "${(v * 100).toInt()}", color = Color(0xFFB8C7D9), fontFamily = MONO, fontSize = 9.sp)
    }
}

@Composable
fun SettingsPanel(s: Inst, acc: Color, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xE6000000)).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxHeight(.92f).widthIn(max = 560.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B1118))
                .border(1.dp, acc, RoundedCornerShape(10.dp)).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚙ CONFIGURACIÓN", Modifier.weight(1f), color = acc, fontFamily = MONO, fontSize = 14.sp)
                Neon("CERRAR", false, acc) { onClose() }
            }
            val sl = SliderDefaults.colors(thumbColor = acc, activeTrackColor = acc, inactiveTrackColor = Color(0xFF1A2733))
            val tc = Color(0xFFB8C7D9)
            Text("Latencia de salida: " + (if (s.lat < 0) "--" else "%.1f ms".format(s.lat)), color = Color(0xFF7CFFB2), fontFamily = MONO, fontSize = 12.sp)
            Text("Buffer: ${s.bursts} (menos = menor latencia, más riesgo de cortes)", color = tc, fontFamily = MONO, fontSize = 12.sp)
            Slider(s.bursts.toFloat(), { s.bursts = it.roundToInt(); NativeAudio.setBursts(s.bursts) }, valueRange = 1f..4f, steps = 2, colors = sl)
            Text("Sensibilidad (velocidad mínima): ${(s.velMin * 100).toInt()}%", color = tc, fontFamily = MONO, fontSize = 12.sp)
            Slider(s.velMin, { s.velMin = it }, valueRange = .2f..1f, colors = sl)
            Text("Brillo de LEDs: ${(s.led * 100).toInt()}%", color = tc, fontFamily = MONO, fontSize = 12.sp)
            Slider(s.led, { s.led = it }, valueRange = .3f..1f, colors = sl)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ajuste fino de faders", Modifier.weight(1f), color = tc, fontFamily = MONO, fontSize = 12.sp)
                Switch(s.fine, { s.fine = it }, colors = SwitchDefaults.colors(checkedThumbColor = acc, checkedTrackColor = acc.copy(alpha = .4f)))
            }
            Text("Color de acento", color = tc, fontFamily = MONO, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ACC_NAMES.forEachIndexed { i, n -> Neon(n, s.accent == i, ACCENTS[i]) { s.accent = i } }
            }
            Neon("RESTABLECER FADERS", false, acc) {
                val d = listOf(.8f, .8f, .15f, 0f, .3f, .15f, .5f, 0f)
                for (i in 0..7) s.setFader(i, d[i])
            }
            Neon("BORRAR SECUENCIA", false, acc) {
                NativeAudio.clearPattern(); for (l in 0 until 32) s.pat[l] = 0; s.patVer++
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Instrument() {
    val s = remember { Inst() }
    val acc = ACCENTS[s.accent]
    var settings by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        for (i in 0..7) NativeAudio.setParam(i, s.faders[i])
        NativeAudio.setParam(8, s.bpm.toFloat()); NativeAudio.setParam(9, s.len.toFloat())
        for (l in 0 until 32) for (k in 0 until 32) if (((s.pat[l] shr k) and 1) == 1) NativeAudio.setCell(l, k, true)
    }
    LaunchedEffect(s.root, s.scale, s.oct) { for (l in 0 until 16) NativeAudio.setLaneNote(l, s.deg(l)) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { }; s.cur = NativeAudio.getStep() } }
    LaunchedEffect(Unit) { while (true) { s.lat = NativeAudio.getLatencyMs(); delay(1000) } }
    Box(Modifier.fillMaxSize().background(Color(0xFF05060A))) {
        Row(Modifier.fillMaxSize().safeDrawingPadding().padding(8.dp)) {
            PadGrid(s, acc, Modifier.fillMaxHeight().aspectRatio(1f))
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    MODES.forEachIndexed { i, m -> Neon(m, s.mode == i, acc) { s.mode = i } }
                    Neon("⚙ CONFIG", false, acc) { settings = true }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Neon(if (s.playing) "■ STOP" else "▶ PLAY", s.playing, acc) { s.playing = !s.playing; NativeAudio.setPlaying(s.playing) }
                    Neon("−", false, acc) { s.bpm = (s.bpm - 5).coerceAtLeast(40); NativeAudio.setParam(8, s.bpm.toFloat()) }
                    Box(Modifier.padding(horizontal = 2.dp, vertical = 6.dp)) { Text("${s.bpm} BPM", color = Color.White, fontFamily = MONO, fontSize = 11.sp) }
                    Neon("+", false, acc) { s.bpm = (s.bpm + 5).coerceAtMost(240); NativeAudio.setParam(8, s.bpm.toFloat()) }
                    NeonDrop("TÓNICA", NOTES[s.root], NOTES, acc) { s.root = it }
                    NeonDrop("ESCALA", SCALES[s.scale].first, SCALES.map { it.first }, acc) { s.scale = it }
                    NeonDrop("OCT", "${s.oct}", (0..6).map { "$it" }, acc) { s.oct = it }
                    if (s.mode == 1) NeonDrop("ACORDE", CHORDS[s.chord].first, CHORDS.map { it.first }, acc) { s.chord = it }
                    if (s.mode == 3) NeonDrop("LARGO", "${s.len}", listOf("16", "32"), acc) { s.len = if (it == 0) 16 else 32; NativeAudio.setParam(9, s.len.toFloat()) }
                }
                Text("marc.OS v2", color = acc.copy(alpha = .7f), fontFamily = MONO, fontSize = 10.sp)
                val bad = s.lat > 50f
                Text(
                    (if (s.lat < 0) "LATENCIA: --" else "LATENCIA %.1f ms".format(s.lat)) + (if (bad) "  ⚠ ¿Bluetooth? Usa altavoz o cable" else ""),
                    color = if (bad) Color(0xFFFF5555) else Color(0xFF7CFFB2), fontFamily = MONO, fontSize = 10.sp
                )
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    for (i in 0..7) Fader(i, s, acc, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
        if (settings) SettingsPanel(s, acc) { settings = false }
    }
}
