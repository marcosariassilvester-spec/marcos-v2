#pragma once
#include <oboe/Oboe.h>
#include <atomic>
#include <vector>
#include <memory>
#include <cstdint>

// Motor de audio marc.OS: todo el sonido y el secuenciador viven en el hilo de audio.
// La UI solo empuja eventos a una cola sin bloqueos (un unico productor: el hilo principal).
class AudioEngine : public oboe::AudioStreamCallback {
public:
    AudioEngine();
    bool start();
    void stop();
    void noteOn(int id, int midi, float vel) { push(1, id, midi, vel); }
    void noteOff(int id)                     { push(2, id, 0, 0); }
    void drum(int idx, float vel)            { push(3, idx, 0, vel); }
    void setPlaying(bool p)                  { push(4, 0, p ? 1 : 0, 0); }
    // Parametros: 0 vol, 1 cutoff, 2 res, 3 atk, 4 rel, 5 delay, 6 onda, 7 swing (0..1); 8 bpm; 9 largo (pasos)
    void setParam(int i, float v) { if (i >= 0 && i < 12) P[i].store(v, std::memory_order_relaxed); }
    void setCell(int lane, int step, bool on);
    void clearPattern() { for (auto &p : pat) p.store(0); }
    void setLaneNote(int lane, int midi) { if (lane >= 0 && lane < 16) laneNote[lane].store(midi); }
    int step() const { return stepNow.load(std::memory_order_relaxed); }
    float latencyMs();
    void setBursts(int n);

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *, void *, int32_t) override;
    void onErrorAfterClose(oboe::AudioStream *, oboe::Result) override;

private:
    struct Ev { uint8_t type = 0, a = 0, b = 0; float v = 0; };
    struct Synth { bool on = false, rel = false; int id = 0, gate = -1; float freq = 0, ph = 0, env = 0, vel = 0, low = 0, band = 0; };
    struct Drum { bool on = false; int type = 0; uint32_t n = 0; float vel = 0, ph = 0, lp = 0; };
    static constexpr int RN = 512;

    void push(uint8_t t, int a, int b, float v);
    void noteOnI(int id, int midi, float vel, int gate);
    void drumI(int idx, float vel);
    float noise();
    float L(int i) const { return P[i].load(std::memory_order_relaxed); }

    std::shared_ptr<oboe::AudioStream> stream;
    int bursts = 2;
    bool wanted = false;
    float sr = 48000.f;

    Ev ring[RN];
    std::atomic<uint32_t> wr{0}, rd{0};
    std::atomic<float> P[12];
    std::atomic<uint32_t> pat[32];
    std::atomic<int> laneNote[16];
    std::atomic<int> stepNow{-1};

    Synth syn[16];
    Drum dr[16];
    bool playing = false;
    int curStep = 0, stepLeft = 0;
    uint32_t rng = 22222u;
    std::vector<float> dbuf;
    int dpos = 0, dlen = 14400;
};
