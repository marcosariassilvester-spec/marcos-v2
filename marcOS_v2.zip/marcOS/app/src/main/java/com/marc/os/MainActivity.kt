package com.marc.os

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            var done by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxSize().background(Color(0xFF05060A))) {
                Instrument()
                if (!done) Splash(ACCENTS[0]) { done = true }
            }
        }
    }
    override fun onStart() { super.onStart(); NativeAudio.start() }
    override fun onStop() { super.onStop(); NativeAudio.stop() }
}
