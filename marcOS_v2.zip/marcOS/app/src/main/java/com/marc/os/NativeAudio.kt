package com.marc.os

/** Puente JNI hacia el motor C++ (Oboe). Llamar siempre desde el hilo principal. */
object NativeAudio {
    init { System.loadLibrary("marcos_audio") }
    external fun start(): Boolean
    external fun stop()
    external fun noteOn(id: Int, midi: Int, vel: Float)
    external fun noteOff(id: Int)
    external fun drum(idx: Int, vel: Float)
    /** 0 vol, 1 cutoff, 2 res, 3 atk, 4 rel, 5 delay, 6 onda, 7 swing (0..1); 8 bpm; 9 largo */
    external fun setParam(i: Int, v: Float)
    external fun setPlaying(p: Boolean)
    external fun setCell(lane: Int, step: Int, on: Boolean)
    external fun clearPattern()
    external fun setLaneNote(lane: Int, midi: Int)
    external fun getStep(): Int
    external fun getLatencyMs(): Float
    external fun setBursts(n: Int)
}
